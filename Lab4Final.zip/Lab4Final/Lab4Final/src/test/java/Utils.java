// Configuration class for Form Automation project

public class Utils {
    final static String BASE_URL = "https://formy-project.herokuapp.com/form";
    final static String CHROME_DRIVER_LOCATION = "chromedriver";
}
